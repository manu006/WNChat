//
//  WebViewViewController.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 17/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit

class WebViewViewController: UIViewController {
    
    @IBOutlet var myWebView: UIWebView!
    var favNewsIndicator:Bool = false
    
    @IBOutlet var btnFav: UIBarButtonItem!
    var webInstace:String!
    var newsDataRef:Articles!
    var favouriteIndicator:Bool = false
    @IBAction func btnShare(_ sender: Any) {
        let activityVC = UIActivityViewController(activityItems: [newsDataRef.heading,webInstace], applicationActivities: nil)
        // activityVC.excludedActivityTypes = [UIActivityTypeAirDrop, UIActivityTypeAddToReadingList]
        self.present(activityVC, animated: true, completion: nil)
        //print(newsDataRef!)
    }
    
    @IBAction func btnFavourite(_ sender: Any) {
        if !favouriteIndicator {
            self.btnFav.image = #imageLiteral(resourceName: "if_like_309056")
            UserDefaults.standard.set("\(newsDataRef!.heading)", forKey: "heading\(ApiManager.cont)")
            UserDefaults.standard.set("\(newsDataRef!.desc)", forKey: "desc\(ApiManager.cont)")
            UserDefaults.standard.set("\(newsDataRef!.imageUrl)", forKey: "img\(ApiManager.cont)")
            UserDefaults.standard.set("\(newsDataRef!.url)", forKey: "url\(ApiManager.cont)")
            
            ApiManager.cont+=1
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        if favNewsIndicator {
            self.btnFav.image = #imageLiteral(resourceName: "if_like_309056")
        }
        let spinner = MBProgressHUD.showAdded(to: self.view, animated:true)
        spinner.label.text = "Loading"
        let url = URL(string: webInstace!)
        myWebView.loadRequest(URLRequest(url : url!))
        
        MBProgressHUD.hide(for: self.view, animated: true)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
