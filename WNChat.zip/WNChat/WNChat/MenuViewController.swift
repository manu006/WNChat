//
//  MenuViewController.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 18/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import FBSDKShareKit

class MenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var lblCoverImage: UIImageView!
    @IBOutlet weak var lblProfileImage: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var tableView1: UITableView!
    
    let catageoryArray:[String] = ["all","business","entertainment","gaming","general","music","politics","science-and-nature","sport","technology"]
    
//MARK:- Login button action
    @IBAction func btnLogin(_ sender: UIButton) {
        if !UserDefaults.standard.bool(forKey: "isLogged"){
            btnLogin.setTitle("Log Out                  ", for: .normal)
            let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
            fbLoginManager.logIn(withReadPermissions: ["email"], from: self) { (result, error) -> Void in
                if (error == nil){
                    let fbloginresult : FBSDKLoginManagerLoginResult = result!
                    if(fbloginresult.grantedPermissions.contains("email"))
                    {
                        self.getFBUserData()
                        UserDefaults.standard.set(true, forKey: "isLogged")

                    }
                }
            }
            UserDefaults.standard.set(true, forKey: "isLogged")
        }else{
            btnLogin.setTitle("Login                    ", for: .normal)
            let logOutManager:FBSDKLoginManager = FBSDKLoginManager()
            logOutManager.logOut()
            print("    Logout ")
            lblName.text = ""
            lblProfileImage.image = nil
            lblEmail.text = ""
            UserDefaults.standard.set(false, forKey: "isLogged")
        }

     }
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView1.delegate = self
        tableView1.dataSource = self
        
        if UserDefaults.standard.bool(forKey: "isLogged") {
            btnLogin.setTitleColor(.red, for: .normal)
            btnLogin.setTitle("Log Out                  ", for: .normal)
            
        }else{
            btnLogin.setTitleColor(.red, for: .normal)
            btnLogin.setTitle("Login                    ", for: .normal)
        }

        // Do any additional setup after loading the view.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        lblProfileImage.layer.cornerRadius = lblProfileImage.frame.size.height/2
        lblProfileImage.clipsToBounds = true
        //print("\(UserDefaults.standard.string(forKey: "image")!)")
        lblProfileImage.downloadImage(from: (UserDefaults.standard.string(forKey: "image"))!)
        lblName.text = UserDefaults.standard.string(forKey: "name") ?? ""
        lblEmail.text = UserDefaults.standard.string(forKey: "email") ?? "email not linked"

    }
    
    //MARK:- Functions for TableView
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Categories"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return catageoryArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "menuCell", for: indexPath)
        cell.textLabel?.text = String(catageoryArray[indexPath.row].characters.prefix(1)).uppercased() + String(catageoryArray[indexPath.row].characters.dropFirst())
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            ApiManager.indicator = false
            
        }else{
            ApiManager.catageoryRef = catageoryArray[indexPath.row]
            ApiManager.indicator = true
            
        }
    }
    
//MARK:- Login function
    func getFBUserData(){
        if((FBSDKAccessToken.current()) != nil){
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil){
                    //everything works print the user data
                    print(result ?? "")
                }
            })
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
