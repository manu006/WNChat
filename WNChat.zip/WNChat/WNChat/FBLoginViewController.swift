//
//  FBLoginViewController.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 18/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class FBLoginViewController: UIViewController,FBSDKLoginButtonDelegate{

    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let btnLogin = FBSDKLoginButton()
        self.view.addSubview(btnLogin)
        btnLogin.frame = CGRect(x: 16, y: 50, width: self.view.frame.width-32, height: 50)
        btnLogin.delegate = self
        btnLogin.readPermissions = ["email","public_profile","user_friends"]
        
        // Do any additional setup after loading the view.
    }

    //MARK:- Login Button functions
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("Successfully Logged out")
        UserDefaults.standard.set(false, forKey: "isLogged")

        
    }
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        UserDefaults.standard.set(true, forKey: "isLogged")
        if error == nil {
            FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id, name, picture, email"]).start{ (connection, results, error1) in
                if error1 == nil {
                print(results!)
                    if let data = results as? [String:AnyObject]{
                        if let emailRef = data["email"] as? String{ UserDefaults.standard.set("\(emailRef)", forKey: "email")}
                        if let nameRef = data["name"] as? String{ UserDefaults.standard.set("\(nameRef)", forKey: "name")}
                        if let pictureRef = ( data["picture"]! ["data"]!! as! [String:AnyObject])["url"]{
                            if let imageRef = pictureRef as? String  {
                                UserDefaults.standard.set("\(imageRef)", forKey: "image")
                             //   print(UserDefaults.standard.string(forKey: "image")!)
                                return}
                            //                        print("\(imageRef)")
                        }

                    }
                   // print(UserDefaults.standard.bool(forKey: "isLogged"))

                }else{
                print(error1!.localizedDescription)
                }
            }
            performSegue(withIdentifier: "FbLoginVCtoTabBar", sender: self)

        }else{
        print(error!.localizedDescription)
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
