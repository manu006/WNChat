//
//  ApiManager.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 17/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import Foundation
import CoreLocation

//MARK:- Weather Structure
struct Weather {
    var summary :String
    var temperature:Double
    var icon:String
}
let hostURL = "https://api.darksky.net/forecast/2bd3dd6a44388ee63e35b1ade129c6b0/"

//MARK:- News Structure
struct Articles{
    var heading:String
    var desc : String
    var url : String
    var imageUrl :String
}
let channelNewsURL = "https://newsapi.org/v1/articles?source="
struct ChannelName {
    var name:String
    var url:String
    var category:String
    var id:String
}
let channelHostURL = "https://newsapi.org/v1/sources?language=en"

//MARK:- ApiManager Class
class ApiManager {
    static var cont:Int = 0
    static var catageoryRef:String = ""
    static var indicator:Bool = false

//MARK:- Weather Function
    class func weatherOfLocation(location:CLLocationCoordinate2D,completion: @escaping ([Weather]?) -> ()){
    let url = hostURL+"\(location.latitude),\(location.longitude)"
        let siteRequest = URLRequest(url: URL(string: url)!)
        var summaryData:String = ""
        var temperatureData:Double = 0.0
        var iconData:String = ""
        
        let task = URLSession.shared.dataTask(with: siteRequest) { (data:Data?, response:URLResponse?, error:Error?) in
            
            var weatherForecastArray:[Weather] = []
            
            if let data = data {
                
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] {
                        if let dailyForecasts = json["daily"] as? [String:Any] {
                            if let dailyData = dailyForecasts["data"] as? [[String:Any]] {
                                for dataPoint in dailyData {
                                    if  let summaryRef = dataPoint["summary"] as? String{
                                        summaryData = summaryRef
                                    }
                                    else {
                                        print("Summary not found")
                                        return}
                                    if let iconRef = dataPoint["icon"] as? String {
                                    iconData = iconRef
                                    }
                                        else {
                                        print("Icon not found")
                                        return}
                                    if let temperatureRef = dataPoint["temperatureMax"] as? Double{
                                    temperatureData = temperatureRef
                                    }
                                        else {
                                        print("Temperature not found")
                                        return}
                                    weatherForecastArray.append(Weather(summary: summaryData, temperature: temperatureData, icon: iconData))
                                    
                                }
                            }
                        }
                        
                    }
                }catch {
                    print(error.localizedDescription)
                }
                
                completion(weatherForecastArray)
            }
        }
        task.resume()
    }
    
//MARK:- Channel Name Function
    class func channelNames(completion: @escaping ([ChannelName]) -> ()){
        var nameData:String = ""
        var urlData:String = ""
        var categoryData:String = ""
        var idData:String = ""
        
        let siteRequest = URLRequest(url: URL(string:channelHostURL)!)
        let task = URLSession.shared.dataTask(with: siteRequest){(data:Data?,response:URLResponse?,error:Error?) in
            var channelList = [ChannelName]()
            
            if let data = data{
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any]{
                        if let source = json["sources"] as? [[String:Any]]{
                            for dataPoint in source {
                                if let nameRef = dataPoint["name"] as? String {
                                nameData = nameRef
                                }else{
                                    print("Name not found")
                                    return}
                                if let urlRef = dataPoint["url"] as? String {
                                urlData=urlRef
                                }else{
                                    print("URL not found")
                                    return}
                                if let categoryRef = dataPoint["category"] as? String {
                                categoryData=categoryRef
                                }else{
                                    print("Category not found")
                                    return}
                                if let idRef = dataPoint["id"] as? String {
                                idData=idRef
                                }else{
                                    print("Category not found")
                                    return}
                                channelList.append(ChannelName(name: nameData, url: urlData, category: categoryData,id:idData))
                            }
                            //print("\(channelList)")
                        }
                    }
                }
                catch {
                    print(error.localizedDescription)
                }
                completion(channelList)
            }
        }
        task.resume()
    }
//
    class func newsOfChannel(channel:String,completion: @escaping([Articles]?) -> ()){
        var headingData:String = ""
        var descData:String = ""
        var imageData:String = ""
        var urlData:String = ""
        
        let url = channelNewsURL+"\(channel)&sortBy=top&apiKey=97b18be9bd2d47c4b34743cc6e99e2e6"
        let siteRequest = URLRequest(url:URL(string:url)!)
        let task = URLSession.shared.dataTask(with: siteRequest){(data:Data?,response:URLResponse?,error:Error?) in
            var newsFeedArray:[Articles] = []
            if let data = data {
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String:Any] {
                        if let article = json["articles"] as? [[String:Any]]{
                            for dataPoint in article {
                                if let headingRef = dataPoint["title"] as? String{
                                headingData = headingRef
                                }else{
                                    print("Title not found")
                                    return}
                                if let descRef = dataPoint["description"] as? String{
                                descData = descRef
                                }else{
                                    print("Description not found")
                                    return}
                                if let imageRef = dataPoint["urlToImage"] as? String {
                                imageData = imageRef
                                }else{
                                    print("Image not found")
                                    return}
                                if let urlRef = dataPoint["url"] as? String {
                                urlData = urlRef
                                }else{
                                    print("URL not found")
                                    return}
                                newsFeedArray.append(Articles(heading: headingData, desc: descData, url:urlData, imageUrl: imageData))
                            }
                        }
                    }
                }
                catch{
                    print(error.localizedDescription)
                }
                completion(newsFeedArray)
            }
        }
        task.resume()
    }
}
