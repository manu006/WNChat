//
//  NewsChannelTableViewController.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 17/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit

class NewsChannelTableViewController: UITableViewController {

    
    var channelsList = [ChannelName]()
    var instance:Int!
    //let menuLacher = MenuLauncher()
    var catageoryNews = [ChannelName]()
    var seagueHelper:Bool = false
    var categoryCount:Int = 0
    var displayManager:Bool = false

    @IBOutlet weak var btnMenu: UIBarButtonItem!
    @IBOutlet var tableView1: UITableView!
    @IBAction func btnFav(_ sender: UIBarButtonItem) {
        
    }
    //MARK:- Menu Button Function
    @IBAction func menu(_ sender: UIBarButtonItem) {
        if revealViewController() != nil{
            btnMenu.target = revealViewController()
            btnMenu.action = #selector(SWRevealViewController.revealToggle(_:))
            self.view.addGestureRecognizer(revealViewController().panGestureRecognizer())
            
            self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())
        }
    }
    
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let spinner = MBProgressHUD.showAdded(to: self.view, animated:true)
        spinner.label.text = "Loading"

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    ///MARK:- View Lifecycle
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        ApiManager.channelNames(completion: { (results:[ChannelName]?) in
            
            if let channelData = results {
                self.channelsList = channelData
                
                for pos in self.channelsList{
                    if ApiManager.catageoryRef == pos.category{
                        //                        for indicate in self.catageoryNews{
                        //                            if indicate.name != pos.name {
                        self.catageoryNews.append(pos)
                        //                            }
                        //                            }
                    }
                    
                }
                
                DispatchQueue.main.async {
                    self.tableView1.reloadData()
                }
                
            }
            
        })
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(true)
        if ApiManager.indicator {
            if !displayManager {
                categoryCount = catageoryNews.count
            }
        }
        displayManager = true
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //print("\(channelsList.count)")
        if ApiManager.indicator {
            seagueHelper = true
            if displayManager {
                return categoryCount
            }else{
                return catageoryNews.count
            }
        }else{
            return channelsList.count
        }
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        MBProgressHUD.hide(for: self.view, animated: true)
        let cell = tableView1.dequeueReusableCell(withIdentifier: "channelCell", for: indexPath) as! NewsChannelTableViewCell
        if ApiManager.indicator {
            cell.lblTitle.text = catageoryNews[indexPath.row].name
            cell.lblSubtitle.text = ""
        }else{
            cell.lblTitle.text = channelsList[indexPath.row].name
            cell.lblSubtitle.text = ("Category : \(channelsList[indexPath.row].category)")
        }
        //print("hii guys")
        if indexPath.row == catageoryNews.count && ApiManager.indicator {
            ApiManager.catageoryRef = ""
            ApiManager.indicator = false
            
        }
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        instance = indexPath.row
        performSegue(withIdentifier: "channelVCtoNewsVC", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "channelVCtoNewsVC"{
            let vc = segue.destination as! NewsFeedViewController
            if seagueHelper{
                vc.idRef = catageoryNews[instance].id
                vc.title = catageoryNews[instance].name
            }else{
                vc.idRef = channelsList[instance].id
                vc.title = channelsList[instance].name
            }
        }
    }

   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
