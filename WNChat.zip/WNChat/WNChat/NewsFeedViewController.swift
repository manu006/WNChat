//
//  NewsFeedViewController.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 17/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit

class NewsFeedViewController: UIViewController,UITableViewDelegate,UITableViewDataSource  {

    @IBOutlet weak var tableView1: UITableView!
    var localInstance:Int!
    var idRef:String!
    var newsData = [Articles]()

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView1.delegate = self
        tableView1.dataSource = self
        let spinner = MBProgressHUD.showAdded(to: self.view, animated:true)
        spinner.label.text = "Loading"

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        ApiManager.newsOfChannel(channel: idRef, completion: { (results:[Articles]?) in
            
            if let newsData = results {
                self.newsData = newsData
                
                DispatchQueue.main.async {
                    self.tableView1.reloadData()
                }
            }
        })
    }
    
    // MARK: - Table view data source
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return newsData.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //        ActivityIndicator.stopAnimating()
        //        ActivityIndicator.removeFromSuperview()
        MBProgressHUD.hide(for: self.view, animated: true)
        let cell = tableView.dequeueReusableCell(withIdentifier: "newsFeedCell", for: indexPath) as! NewsFeedTableViewCell
        cell.lblDescription.text = newsData[indexPath.row].desc
        cell.lblHeading.text = newsData[indexPath.row].heading
        cell.lblImage.downloadImage(from: (newsData[indexPath.row].imageUrl))
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        localInstance = indexPath.row
        performSegue(withIdentifier: "newsVCtoWebVC", sender: self)
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let vc = segue.destination as! WebViewViewController
        vc.webInstace = newsData[localInstance].url
        vc.title = self.title
        vc.newsDataRef = newsData[localInstance]
        vc.favouriteIndicator = false
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UIImageView {
    
    func downloadImage(from url : String){
        //print("my\(url)")
        let urlRequest = URLRequest(url: URL(string: url) ?? URL(string: "http://www.abc.net.au/news/image/8863698-1x1-700x700.jpg")! )
        let task = URLSession.shared.dataTask(with: urlRequest) {(data,response,error) in
            
            if error != nil{
                print("error")
                return
            }
            else {
                DispatchQueue.main.async {
                    self.image = UIImage(data:data!)
                }
            }
        }
        task.resume()
    }
}
