//
//  WeatherViewController.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 17/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate  {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var forecastData = [Weather]()
    
    //MARK:- View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        searchBar.delegate = self
        let spinner = MBProgressHUD.showAdded(to: self.view, animated:true)
        spinner.label.text = "Loading"
        getWeatherForLocation(location: "Jaipur")


        // Do any additional setup after loading the view.
    }
    
    //MARK:- SearchBar function
    func searchBarSearchButtonClicked(_ searchBar:UISearchBar) {
        searchBar.resignFirstResponder()
        if let placeString = searchBar.text, !placeString.isEmpty{
            getWeatherForLocation(location: placeString)
            // print("Hello")
        }
    }
    
    //MARK:- Weather forecaste function
    func getWeatherForLocation(location:String) {
        CLGeocoder().geocodeAddressString(location) {(placemark:[CLPlacemark]?,error:Error?) in
            if error == nil{
                if let location = placemark?.first?.location {
                    ApiManager.weatherOfLocation(location: location.coordinate, completion: { (results:[Weather]?) in
                        
                        if let weatherData = results {
                            self.forecastData = weatherData
                            
                            DispatchQueue.main.async {
                                self.tableView.reloadData()
                            }
                            
                        }
                        
                    })
                }
            }
        }
    }
    
    //MARK:- TableView funtions
    func numberOfSections(in tableView: UITableView) -> Int {
        return forecastData.count
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let date = Calendar.current.date(byAdding: .day, value: section, to: Date())
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM dd, yyyy"
        return dateFormatter.string(from: date!)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //        ActivityIndicator.stopAnimating()
        //        ActivityIndicator.removeFromSuperview()
        MBProgressHUD.hide(for: self.view, animated: true)
        let cell = tableView.dequeueReusableCell(withIdentifier: "weatherCell", for: indexPath) as! WeatherTableViewCell
        let weatherObj = forecastData[indexPath.section]
        cell.lblTitle.text = weatherObj.summary
        cell.lblSubtitle.text = " \(Int(weatherObj.temperature)) °F"
        cell.lblImage.image = UIImage(named: weatherObj.icon)
        return cell
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
