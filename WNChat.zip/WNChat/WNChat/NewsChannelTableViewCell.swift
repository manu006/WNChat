//
//  NewsChannelTableViewCell.swift
//  WNChat
//
//  Created by Mahendra Singh Shekhawat on 17/09/17.
//  Copyright © 2017 Mahendra Singh Shekhawat. All rights reserved.
//

import UIKit

class NewsChannelTableViewCell: UITableViewCell {

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubtitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
